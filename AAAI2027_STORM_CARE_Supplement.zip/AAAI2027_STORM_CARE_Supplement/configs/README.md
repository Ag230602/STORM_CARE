# Configs

This repository does not read hyperparameters from YAML at runtime — each
module's config is a Python dataclass (`model/<module>/config.py`), and
`--demo` CLI flags apply a documented override profile on top of the
dataclass defaults. **These YAML files are a reference mirror of the exact
values embedded in the checkpoints shipped in `checkpoints/`, extracted from
the checkpoints' own saved config dicts** — they are for human/reviewer
readability, not something the scripts parse. If you want to actually change
a hyperparameter, edit the corresponding dataclass in `model/<module>/config.py`
directly; editing these YAML files has no effect on `reproduce/*.sh`.

- `foundation.yaml` — Module 1 (self-supervised pretraining transformer)
- `physics.yaml` — Module 2 (physics-informed graph neural operator)
- `disaster_graph.yaml` — Module 3 (humanitarian disaster graph)
- `world_model.yaml` — Module 4 (RSSM world model)
- `track_baselines.yaml` — LSTM / Transformer / DCRNN / GNO+DynGNN case-study models
- `humanitarian_baselines.yaml` — RF / MLP / XGBoost baselines for Table 2
- `default.yaml` — index of the above, for a single entry point
