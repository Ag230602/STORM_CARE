# Data

This is a **representative subset**, not the full research dataset, per
AAAI's guidance for oversized data/media.

## Where the actual files are

The sample data lives under `your-repo/data/data/...` at the package root,
not under this `data/` directory. This mirrors the exact relative paths
hardcoded in the shipped scripts (`model/`, `scripts/`, `benchmark.py`) —
those paths are baked into the code we didn't want to risk rewriting under
deadline, so the data is placed where the code already expects to find it.
This file exists at the location the package layout convention calls for;
treat it as the map, not the territory.

| What | Where | Size |
|---|---|---|
| HURDAT2 (full public NOAA Atlantic hurricane database, 1851-2024) | `your-repo/data/data/raw/hurdat2/hurdat2_atlantic.txt` | 6.7 MB |
| ERA5 atmospheric fields, Hurricane Irma 2017 | `your-repo/data/data/raw/era5/irma_2017/era5_pl_irma_2017.nc` | 6.9 MB |
| ERA5 atmospheric fields, Hurricane Ian 2022 | `your-repo/data/data/raw/era5/ian_2022/era5_pl_ian_2022.nc` | 5.9 MB |
| Processed Irma/Ian track CSVs (case-study benchmark input) | `your-repo/data/data/processed/tracks/{irma_2017,ian_2022}_hurdat2.csv` | 4 KB each |
| CDC SVI 2022, Florida tract-level (real data) | `your-repo/data/data/raw/data/raw/vulnerability/vulnerability_grid_clean.csv` | 237 KB |
| Facility x SVI join (real SVI values, synthetic facility IDs — see caveat) | `your-repo/data/data/processed/facility_svi.csv` | 414 KB |

## What is and isn't real data — read this before citing coverage numbers

- **HURDAT2**: real, full, public. Table 1's 107-storm test-partition
  benchmark is computed on this file in its entirety.
- **ERA5**: real. These are the *only two storms* (of 519 storms since 1995
  in HURDAT2, 107 of which are in the test partition) with ERA5 atmospheric
  fields available anywhere in this project — coverage is 1/107 test storms.
  The Irma/Ian benchmark in `tables/table_case_study_track_error.csv` is a
  **window-level case study**, not held-out-storm generalization, and is
  labeled that way in every table/report that uses it.
- **CDC SVI**: real 2022-release data, consumed by Module 1's vulnerability
  features (`model/foundation/config.py`'s `vulnerability_path`).
- **`facility_svi.csv`**: the `RPL_THEME*` columns are real SVI values, but
  the facility IDs (`shelter_0`, `hospital_1`, ...) are synthetic — this
  file is **not** wired into Module 3's humanitarian-label generator, which
  uses an independent synthetic Rankine-vortex scenario simulator instead
  (`model/disaster_graph/schema.py::build_dataset` /
  `humanitarian_targets`). See `results/example_outputs/
  humanitarian_metrics_audit.md` and `submission_blockers_response.md` for
  the full accounting.
- **WorldPop, IBTrACS, HDX facility snapshots**: not used anywhere in this
  codebase. `ibtracs_path` is `None` in the shipped foundation checkpoint's
  config (see `configs/foundation.yaml`) — the pipeline falls back to
  HURDAT2 + a synthetic global-storm generator when IBTrACS is not
  supplied, which is the case for every checkpoint in this package.

## Splits

The frozen storm-level train/val/test split all reported numbers are
computed on is `splits/storm_splits.json` (342 train / 70 val / 107 test
storms, split by year boundary — 1995-2015 / 2016-2019 / 2020+ — to prevent
storm-level leakage). sha256:
`87bae628702eaf8bf887ba039b9f8aeff1e70123099c5b5a33b9d6a338f27959`.
