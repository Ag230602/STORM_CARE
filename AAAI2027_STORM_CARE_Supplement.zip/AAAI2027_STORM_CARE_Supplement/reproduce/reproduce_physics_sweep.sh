#!/usr/bin/env bash
# Reproduce the E5 physics constraint-weight sweep (no-physics + scales
# 0.1/0.3/1.0/3.0). ~1 minute on CPU.
set -e
cd "$(dirname "$0")/.."
python3 scripts/run_physics_weight_sweep.py --seeds 42
