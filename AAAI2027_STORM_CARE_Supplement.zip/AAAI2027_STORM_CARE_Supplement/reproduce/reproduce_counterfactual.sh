#!/usr/bin/env bash
# Reproduce the E3 evacuation dose-response sweep (12h/24h/36h) and its
# bootstrap monotonicity + Holm-corrected significance test.
set -e
cd "$(dirname "$0")/.."
python3 -m model.counterfactual.run --demo
python3 scripts/check_dose_response.py \
  --input metrics/counterfactual/counterfactual_outcomes_long.csv \
  --out-dir metrics/counterfactual \
  --order baseline earlier_evacuation earlier_evacuation_24h earlier_evacuation_36h
