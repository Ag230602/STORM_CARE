#!/usr/bin/env bash
# Run every reproduction script in sequence. ~5-10 minutes total on CPU.
set -e
cd "$(dirname "$0")"
for s in reproduce_table1.sh reproduce_table2.sh reproduce_table3.sh \
         reproduce_calibration.sh reproduce_counterfactual.sh \
         reproduce_physics_sweep.sh reproduce_case_study.sh; do
  echo "=== running $s ==="
  bash "$s"
done
echo "All reproduction scripts completed. Compare outputs against results/expected_results.csv."
