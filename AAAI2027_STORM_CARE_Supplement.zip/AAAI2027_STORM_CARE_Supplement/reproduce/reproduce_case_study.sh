#!/usr/bin/env bash
# Reproduce the Irma/Ian window-level case-study benchmark (Persistence,
# LSTM, Transformer, GNO+DynGNN) from the bundled small checkpoints.
# Note: DCRNN is excluded from this package (19MB checkpoint, over budget);
# retrain it with scripts/train_dcrnn_baseline.py if needed.
set -e
cd "$(dirname "$0")/.."
python3 benchmark.py
