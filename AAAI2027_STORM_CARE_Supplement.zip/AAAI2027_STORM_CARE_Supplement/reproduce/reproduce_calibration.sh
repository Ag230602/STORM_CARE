#!/usr/bin/env bash
# Reproduce the Module 1 calibration cone-coverage table/figure and its
# consistency audit against the selected checkpoint.
set -e
cd "$(dirname "$0")/.."
python3 scripts/plot_calibration.py
python3 scripts/audit_calibration_consistency.py
