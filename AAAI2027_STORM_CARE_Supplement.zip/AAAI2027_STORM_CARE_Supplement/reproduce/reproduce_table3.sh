#!/usr/bin/env bash
# Reproduce Table 3 (module-scoped ablations).
set -e
cd "$(dirname "$0")/.."
python3 scripts/run_ablations.py
