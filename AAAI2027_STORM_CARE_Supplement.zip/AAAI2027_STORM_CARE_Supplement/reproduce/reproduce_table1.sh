#!/usr/bin/env bash
# Reproduce Table 1 (Persistence / CLIPER, storm-level bootstrap CIs) and the
# Holm-corrected significance test between them.
set -e
cd "$(dirname "$0")/.."
python3 scripts/cliper_baseline.py
