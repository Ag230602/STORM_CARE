#!/usr/bin/env bash
# Reproduce Table 2 (Module 3 humanitarian metrics incl. sMAPE headline)
# against the RF/MLP/XGBoost baselines.
set -e
cd "$(dirname "$0")/.."
python3 scripts/eval_humanitarian.py
